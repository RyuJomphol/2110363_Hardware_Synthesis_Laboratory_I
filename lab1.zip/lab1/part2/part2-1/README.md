## Problem 1: xnor_xor Module

วงจรนี้เป็น Combinational Logic Circuit
ไม่มี memory และผลลัพธ์ขึ้นกับค่า input ณ ขณะนั้นเท่านั้น

## 1️⃣ Basic Syntax: module / input / output / assign

```verilog
  module xnor_xor (
    input  wire in1,
    input  wire in2,
    input  wire in3,
    output wire out
);
```

**อธิบายทีละส่วน**

* `module xnor_xor (...)` 
  คือการประกาศชื่อโมดูล (เหมือนชื่อฟังก์ชัน)

* `input wire in1, in2, in3`
  คือสัญญาณอินพุตของวงจร เป็นชนิด `wire` เพราะเป็น combinational logic

* `output wire out`
  คือเอาต์พุตของวงจร
  ใช้ `wire` เช่นกัน เพราะคำนวณจาก logic gate

## 2️⃣ แปลงรูปวงจรเป็น ASCII Diagram

จากรูป (XNOR ก่อน แล้วเอาไป XOR กับ in3)
สามารถอธิบายเป็น ASCII ได้ดังนี้
```lua

   in1 ----\
            XNOR ----\
   in2 ----/          \
                        XOR ---- out
   in3 ----------------/
```

หรือเขียนเป็นขั้นตอนของสัญญาณ

```ini
step1 = in1 XNOR in2
step2 = step1 XOR in3
```

## 3️⃣ อธิบายโค้ดที่ต้องทำ (หัวใจของโจทย์)

```verilog
assign out = ~(in1 ^ in2) ^ in3;
```

เราจะแยกอธิบาย **จากซ้ายไปขวา**

🔹 (1) `in1 ^ in2` → XOR

- เครื่องหมาย `^` คือ XOR
- ผลลัพธ์เป็น 1 เมื่อค่า ต่างกัน

|in1|	in2|	in1 ^ in2
| ---- | ---- | ---- |
|0	|0	|0
|0	|1	|1
|1	|0	|1
|1	|1	|0

🔹 (2) `~(in1 ^ in2)` → **XNOR**

- ~ คือ NOT
- เมื่อเอา NOT มาครอบ XOR → กลายเป็น **XNOR**

|in1	|in2	|~(in1 ^ in2)
| ---- | ---- | ---- |
|0	|0	|1
|0	|1	|0
|1	|0	|0
|1	|1	|1

📌 **ตรงนี้ตรงกับ XNOR gate ในรูปวงจร**

🔹 (3) `~(in1 ^ in2) ^ in3` → XOR กับ in3

- นำผลจาก XNOR มาก XOR กับ `in3`
- เป็น logic gate ตัวสุดท้ายก่อนออก `out`

เขียนเป็นลำดับความคิดได้ว่า

```verilog
temp = ~(in1 ^ in2);  // XNOR
out  = temp ^ in3;   // XOR
```

## 4️⃣ โค้ดสมบูรณ์ของโมดูล
```verilog
module xnor_xor (
    input  wire in1,
    input  wire in2,
    input  wire in3,
    output wire out
);

    // XNOR ระหว่าง in1 และ in2 แล้วนำไป XOR กับ in3
    assign out = ~(in1 ^ in2) ^ in3;

endmodule
```

