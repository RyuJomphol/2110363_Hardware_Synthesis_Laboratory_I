module cocotb_iverilog_dump();
initial begin
    string dumpfile_path;    if ($value$plusargs("dumpfile_path=%s", dumpfile_path)) begin
        $dumpfile(dumpfile_path);
    end else begin
        $dumpfile("C:\\Users\\fangj\\Documents\\hardware_lab\\lab6-7\\tests\\lab7\\sim_build\\single_cycle_cpu.fst");
    end
    $dumpvars(0, single_cycle_cpu);
end
endmodule
