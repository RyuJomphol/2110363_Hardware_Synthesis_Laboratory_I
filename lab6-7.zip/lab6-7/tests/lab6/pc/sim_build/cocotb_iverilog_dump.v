module cocotb_iverilog_dump();
initial begin
    string dumpfile_path;    if ($value$plusargs("dumpfile_path=%s", dumpfile_path)) begin
        $dumpfile(dumpfile_path);
    end else begin
        $dumpfile("C:\\Users\\fangj\\Documents\\hardware_lab\\lab6-7\\tests\\lab6\\pc\\sim_build\\pc.fst");
    end
    $dumpvars(0, pc);
end
endmodule
