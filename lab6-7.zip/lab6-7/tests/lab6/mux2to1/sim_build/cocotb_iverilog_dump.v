module cocotb_iverilog_dump();
initial begin
    string dumpfile_path;    if ($value$plusargs("dumpfile_path=%s", dumpfile_path)) begin
        $dumpfile(dumpfile_path);
    end else begin
        $dumpfile("C:\\Users\\fangj\\Documents\\hardware_lab\\lab6-7\\tests\\lab6\\mux2to1\\sim_build\\mux2to1.fst");
    end
    $dumpvars(0, mux2to1);
end
endmodule
