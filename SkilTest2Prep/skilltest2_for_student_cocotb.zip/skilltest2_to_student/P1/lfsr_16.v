module lfsr_16 (
    input wire clk,
    input wire reset,
    input wire enable,
    output wire [15:0] lfsr_out
);

`ifdef COCOTB_SIM
  initial begin
    $dumpfile("waveform.vcd");  // Name of the dump file
    $dumpvars(0, lfsr_16);  // Dump all variables for the top module
  end
`endif

endmodule
