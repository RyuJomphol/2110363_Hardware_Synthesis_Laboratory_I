module prob3 (
    input wire clk,
    input wire reset,
    input wire inp,
    output wire out
);

`ifdef COCOTB_SIM
  initial begin
    $dumpfile("waveform.vcd");  // Name of the dump file
    $dumpvars(0, prob3);  // Dump all variables for the top module
  end
`endif

endmodule
